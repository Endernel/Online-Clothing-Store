document.addEventListener("DOMContentLoaded", async () => {
    const loginForm = document.getElementById("login-form");
    const registerForm = document.getElementById("register-form");
    const logoutBtn = document.getElementById("logout");
    const navBar = document.getElementById("navbar");
    const productsContainer = document.getElementById("products-container");
    const userNameElement = document.getElementById("user-name");
    const cartContainer = document.getElementById("cart-items");
    const checkoutButton = document.getElementById("checkout");

    function updateNavbar() {
        const user = JSON.parse(localStorage.getItem("user"));
        if (user) {
            navBar.innerHTML = `
                <a href="index.html">Home</a>
                <a href="profile.html">Profile</a>
                <a href="#" id="logout">Logout</a>
            `;
        } else {
            navBar.innerHTML = `
                <a href="index.html">Home</a>
                <a href="login.html">Login</a>
            `;
        }

        const logoutBtn = document.getElementById("logout");
        if (logoutBtn) {
            logoutBtn.addEventListener("click", () => {
                localStorage.removeItem("token");
                localStorage.removeItem("user");
                updateNavbar();
                window.location.href = "login.html";
            });
        }
    }
    updateNavbar();

    async function loadProducts() {
        if (!productsContainer) return;
        const res = await fetch("http://localhost:3000/products");
        const products = await res.json();

        productsContainer.innerHTML = "";
        products.forEach(product => {
            const productCard = document.createElement("div");
            productCard.classList.add("product-card");
            productCard.innerHTML = `
                <img src="${product.image}" alt="${product.name}" class="product-image">
                <h2>${product.name}</h2>
                <p>${product.description}</p>
                <p><strong>Price:</strong> ${product.price} $</p>
                <button class="add-to-cart" data-id="${product._id}">Add to Cart</button>
            `;
            productsContainer.appendChild(productCard);
        });

        document.querySelectorAll(".add-to-cart").forEach(button => {
            button.addEventListener("click", async (e) => {
                const productId = e.target.dataset.id;
                await addToCart(productId);
            });
        });
    }

    async function addToCart(productId) {
        const token = localStorage.getItem("token");
        if (!token) {
            alert("Please log in to add items to cart.");
            return;
        }

        const res = await fetch("http://localhost:3000/cart/add", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": token
            },
            body: JSON.stringify({ productId })
        });

        const data = await res.json();
        alert(data.message);
        loadCart();
    }

    async function loadCart() {
        if (!cartContainer) return;
        const token = localStorage.getItem("token");
        if (!token) return;
    
        const res = await fetch("http://localhost:3000/cart", {
            headers: { "Authorization": token }
        });
    
        const cartItems = await res.json();
        cartContainer.innerHTML = "";
    
        if (!cartItems.length) {
            cartContainer.innerHTML = "<p>No item in cart</p>";
            checkoutButton.disabled = true;
            return;
        }
    
        cartItems.forEach(item => {
            const li = document.createElement("li");
            li.classList.add("cart-item");
            li.dataset.id = item.productId._id; 
    
            li.innerHTML = `
                <img src="${item.productId.image}" alt="${item.productId.name}" class="cart-image">
                <div class="cart-info">
                    <h3>${item.productId.name}</h3>
                    <p>${item.productId.description}</p>
                    <p><strong>Price:</strong> ${item.productId.price} $</p>
                    <p><strong>Quantity:</strong> ${item.quantity}</p>
                </div>
                <button class="remove-item" data-id="${item.productId._id}">❌ Remove</button>
            `;
    
            cartContainer.appendChild(li);
        });
    
        checkoutButton.disabled = false;
    
        document.querySelectorAll(".remove-item").forEach(button => {
            button.addEventListener("click", async (e) => {
                const productId = e.target.dataset.id;
                await removeFromCart(productId);
            });
        });
    }
    

    async function removeFromCart(productId) {
        const token = localStorage.getItem("token");
        if (!token) return;

        await fetch("http://localhost:3000/cart/remove", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": token
            },
            body: JSON.stringify({ productId })
        });

        loadCart();
    }

    loadProducts();
    loadCart();

    if (registerForm) {
        registerForm.addEventListener("submit", async (e) => {
            e.preventDefault();
            const name = document.getElementById("register-name").value;
            const email = document.getElementById("register-email").value;
            const password = document.getElementById("register-password").value;

            const res = await fetch("http://localhost:3000/register", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ name, email, password })
            });

            const data = await res.json();
            alert(data.message);
            window.location.href = "login.html";
        });
    }

    if (loginForm) {
        loginForm.addEventListener("submit", async (e) => {
            e.preventDefault();
            const email = document.getElementById("login-email").value;
            const password = document.getElementById("login-password").value;

            const res = await fetch("http://localhost:3000/login", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ email, password })
            });

            const data = await res.json();
            if (data.token) {
                localStorage.setItem("token", data.token);
                localStorage.setItem("user", JSON.stringify({ name: data.name, email: data.email }));
                updateNavbar();
                window.location.href = "profile.html";
            } else {
                alert(data.message);
            }
        });
    }

    if (userNameElement) {
        const token = localStorage.getItem("token");

        if (!token) {
            window.location.href = "login.html";
            return;
        }

        try {
            const res = await fetch("http://localhost:3000/profile-data", {
                headers: { "Authorization": token }
            });
            const data = await res.json();

            if (data.name) {
                userNameElement.textContent = data.name;
            } else {
                userNameElement.textContent = "Unknown User";
            }
        } catch (error) {
            console.error("Error loading user data:", error);
            localStorage.removeItem("token");
            window.location.href = "login.html";
        }
    }
});
