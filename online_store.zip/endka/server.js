const express = require("express");
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const cors = require("cors");
const path = require("path");

const app = express();
const PORT = 3000;
const secret = "supersecretkey";

mongoose.connect("mongodb://localhost:27017/final")
    .then(() => console.log("✅ Connected to MongoDB"))
    .catch(err => console.error("❌ MongoDB Connection Error:", err));

const UserSchema = new mongoose.Schema({
    name: String,
    email: String,
    password: String,
    role: { type: String, default: "user" }
});

const ProductSchema = new mongoose.Schema({
    name: String,
    category: String,
    price: Number,
    image: String,
    description: String,
    stock: Number
});

const CartSchema = new mongoose.Schema({
    userId: mongoose.Schema.Types.ObjectId,
    items: [
        {
            productId: { type: mongoose.Schema.Types.ObjectId, ref: "products" }, 
            quantity: { type: Number, default: 1 }
        }
    ]
});


const User = mongoose.model("users", UserSchema);
const Product = mongoose.model("products", ProductSchema);
const Cart = mongoose.model("carts", CartSchema);

app.use(express.json());
app.use(cors());
app.use(express.static(path.join(__dirname, "public")));

async function createAdmin() {
    const existingAdmin = await User.findOne({ email: "aneleka87@gmail.com" });

    if (!existingAdmin) {
        const hashedPassword = await bcrypt.hash("270306", 10);
        await User.create({ name: "Admin", email: "aneleka87@gmail.com", password: hashedPassword, role: "admin" });
        console.log("✅ Admin created!");
    }
}
createAdmin();

app.post("/register", async (req, res) => {
    const { name, email, password } = req.body;
    const existingUser = await User.findOne({ email });

    if (existingUser) return res.status(400).json({ message: "User already exists" });

    const hashedPassword = await bcrypt.hash(password, 10);
    const user = new User({ name, email, password: hashedPassword, role: "user" });
    await user.save();
    
    res.json({ message: "User registered successfully" });
});

app.post("/login", async (req, res) => {
    const { email, password } = req.body;
    const user = await User.findOne({ email });

    if (!user) return res.status(400).json({ message: "User not found" });

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) return res.status(400).json({ message: "Invalid password" });

    const token = jwt.sign({ userId: user._id, role: user.role }, secret, { expiresIn: "1h" });
    res.json({ token, name: user.name, email: user.email, role: user.role });
});

app.get("/profile-data", async (req, res) => {
    const token = req.headers["authorization"];

    if (!token) return res.status(401).json({ message: "Unauthorized" });

    try {
        const decoded = jwt.verify(token, secret);
        const user = await User.findById(decoded.userId);
        res.json({ name: user.name, email: user.email, role: user.role });
    } catch {
        res.status(401).json({ message: "Invalid token" });
    }
});

app.get("/products", async (req, res) => {
    try {
        const products = await Product.find();
        res.json(products);
    } catch (error) {
        res.status(500).json({ message: "Error fetching products", error });
    }
});

app.post("/add-product", async (req, res) => {
    const { name, category, price, image, description, stock } = req.body;

    if (!name || !category || !price || !image || !description || !stock) {
        return res.status(400).json({ message: "All fields are required" });
    }

    const newProduct = new Product({ name, category, price, image, description, stock });
    await newProduct.save();

    res.json({ message: "Product added successfully" });
});

app.get("/cart", async (req, res) => {
    const token = req.headers["authorization"];
    if (!token) return res.status(401).json({ message: "Unauthorized" });

    try {
        const decoded = jwt.verify(token, secret);
        let cart = await Cart.findOne({ userId: decoded.userId }).populate("items.productId");

        if (!cart) {
            cart = new Cart({ userId: decoded.userId, items: [] });
            await cart.save();
        }

        res.json(cart.items); 
    } catch (error) {
        res.status(500).json({ message: "Ошибка получения корзины", error });
    }
});

app.post("/cart/add", async (req, res) => {
    const token = req.headers["authorization"];
    if (!token) return res.status(401).json({ message: "Unauthorized" });

    try {
        const decoded = jwt.verify(token, secret);
        const { productId } = req.body;

        let cart = await Cart.findOne({ userId: decoded.userId });

        if (!cart) {
            cart = new Cart({ userId: decoded.userId, items: [] });
        }

        const existingItem = cart.items.find(item => item.productId.equals(productId));

        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.items.push({ productId, quantity: 1 });
        }

        await cart.save();
        res.json({ message: "Item added to cart", cart });
    } catch {
        res.status(500).json({ message: "Error adding to cart" });
    }
});

app.post("/cart/remove", async (req, res) => {
    const token = req.headers["authorization"];
    if (!token) return res.status(401).json({ message: "Unauthorized" });

    try {
        const decoded = jwt.verify(token, secret);
        const { productId } = req.body;

        let cart = await Cart.findOne({ userId: decoded.userId });

        if (cart) {
            cart.items = cart.items.filter(item => !item.productId.equals(productId));
            await cart.save();
        }

        res.json({ message: "Item removed from cart", cart });
    } catch {
        res.status(500).json({ message: "Error removing from cart" });
    }
});

app.listen(PORT, () => console.log(`✅ Server running on http://localhost:${PORT}`));
